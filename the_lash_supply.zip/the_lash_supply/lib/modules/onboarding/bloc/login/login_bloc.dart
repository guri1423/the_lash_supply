
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:the_lash_supply/modules/onboarding/models/log_in_modal/log_in_modal.dart';

import '../../repository/auth_repositry.dart';

part 'login_event.dart';
part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {


  LoginBloc() : super(LoginInitial()) {
    final AuthRepository authRepository = AuthRepository();
    on<LoginEvent>((event, emit) async {
     if (event is ButtonTapEvent){
       emit (LoginLoading());
       try{
     LoginRespoModel? model=  await authRepository.login(event.modal);

     if (model!.status== 'success'){
       emit(LoginSuccess());

     }
     else
       {
         emit(LoginFail(model.message));
       }
       }
       catch(e){
         emit(LoginFail(e.toString()));
       }
     }
    }
    );
  }
}
