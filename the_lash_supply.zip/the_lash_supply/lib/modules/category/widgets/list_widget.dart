
import 'package:flutter/material.dart';
import 'package:the_lash_supply/core/utils/colors.dart';
import 'package:the_lash_supply/core/utils/fonts.dart';
import 'package:the_lash_supply/modules/products_by_category/pages/products_by_cat.dart';

import '../model/category_modal.dart';

List<String> categoryName = [
  'Volume Lash',
  'Classic Lash',
  'Special Lash',
  'Premade Lash',
  'Accessories Lash',
  'Lash Glue'
];

List<String> categoryImages = [
  'assets/images/Ellipse 3.png',
  'assets/images/Ellipse 3-1.png',
  'assets/images/Ellipse 3-2.png',
  'assets/images/Ellipse 3-3.png',
  'assets/images/Ellipse 3-4.png',
  'assets/images/Ellipse 3-5.png'
];


Widget categoryList(context, {required List<CategoryModal>? modal}){
  return SizedBox(
    height: MediaQuery.of(context).size.height*0.67,
    width: MediaQuery.of(context).size.width,
    child: ListView.builder(
        itemCount: modal!.length,
        itemBuilder: (BuildContext context, int index){
      return GestureDetector(
        onTap: (){
          Navigator.push(context, MaterialPageRoute(builder: (context)=> ProductsByCategory()));
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          child: Container(
            width: 364,
            height: 94,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: containerColors[index],
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                children: [
                  Text(
                    modal[index].cateName!,
                    style: TextStyle(
                      color: AppColors.blackContainer,
                      fontSize: AppFontsHeading.customFontSize-8,
                      fontFamily: AppFontsHeading.customFontText,
                      fontWeight: AppFontsHeading.headingFontWeight,
                    ),
                  ),
                  Spacer(),
                  Container(
                    width: 66,
                    height: 66,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 1, ),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          blurRadius: 4,
                          offset: Offset(0, 0),
                        ),
                      ],
                    ),
                    child: Image.network(modal[index].filename!),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }),
  );
}