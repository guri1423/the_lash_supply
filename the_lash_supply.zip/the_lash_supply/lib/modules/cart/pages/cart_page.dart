


import 'dart:math';

import 'package:flutter/material.dart';
import 'package:the_lash_supply/core/utils/colors.dart';
import 'package:the_lash_supply/modules/cart/widgets/cart_details.dart';
import 'package:the_lash_supply/modules/cart/widgets/cart_widget.dart';
import 'package:the_lash_supply/modules/widgets/custom_app_button.dart';

class CartPage extends StatefulWidget {
  const CartPage({Key? key}) : super(key: key);

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Color(0xff272727),
        ),
        backgroundColor: Colors.white,
        centerTitle: false,
        title: Row(
          children: [
            Text ('Cart',
              style: TextStyle(
                color: Color(0xff272727),
                fontSize: 24,
                fontFamily: "Arya",
                fontWeight: FontWeight.w700,

              ),),
            Spacer(),
            Icon(Icons.search,
            color: AppColors.primaryColor,),
            SizedBox(width: 10,),
            Icon(Icons.favorite_border,
              color: AppColors.primaryColor,),
            SizedBox(width: 10,),
            Icon(Icons.text_snippet_outlined,
              color: AppColors.primaryColor,)
          ],
        ),


      ),

      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Column(
          children: [
            cartWidget(context),

            cartDetails(context),
            SizedBox(height: 10,),

            appButton(context, AppColors.primaryColor, 'Place Order', AppColors.textColor, action: (){})

          ],
        ),
      ),



    );
  }
}
