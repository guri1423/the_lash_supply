import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:the_lash_supply/core/utils/colors.dart';
import 'package:the_lash_supply/modules/product_description/models/product_details_modal.dart';
import 'package:the_lash_supply/modules/widgets/custom_app_button.dart';
Widget productText(context,{required List<ProductDetails>? modal}){
  return Expanded(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          child: Text(
            "Magic Lash",
            style: TextStyle(
              color: Color(0xff333232),
              fontSize: 28,
              fontFamily: "Arya",
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        Text(
          "(Easy Fan – Self Fanning Lashes)",
          style: TextStyle(
            color: Color(0xff333232),
            fontSize: 24,
            fontFamily: "Arya",
            fontWeight: FontWeight.w700,
          ),
        ),
        Text(
          "\$12.00 - \$14.00",
          style: TextStyle(
            color: Color(0xffdd3333),
            fontSize: 20,
          ),
        ),
        Text(
          "Curl of Lashes",
          style: TextStyle(
            color: Color(0xff2d2d2d),
            fontSize: 20,
          ),
        ),
        Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                border: Border.all(color: Color(0xffe2e2e2), width: 1, ),
                color: Color(0xfff6f6f6),
              ),
              child: Center(child: Text('C')),
            ),
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                border: Border.all(color: Color(0xffe2e2e2), width: 1, ),
                color: Color(0xfff6f6f6),
              ),
              child: Center(child: Text('D')),
            ),
          ],
        ),
        Text(
          "Length of Lashes",
          style: TextStyle(
            color: Color(0xff2d2d2d),
            fontSize: 20,
          ),
        ),
        container(context),
        Text(
          "Description",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontFamily: 'Arya',
            color: Color(0xff2d2d2d),
            fontSize: 20,
          ),
        ),
        Text(
          modal![0].desc!,
          style: TextStyle(
            color: Color(0xff333232),
            fontSize: 16,
            fontFamily: "Arya",
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    ),
  );
}
Widget container(context){
  return SizedBox(
    height: MediaQuery.of(context).size.height*0.10,
    width: MediaQuery.of(context).size.width,
    child: GridView.builder(
      itemCount: 12,
      physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        mainAxisExtent: 20,

    ), itemBuilder: (BuildContext context, int index){
      return Container(
        width: 69,
        height: 20,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(3),
          border: Border.all(color: Color(0xffe2e2e2), width: 1, ),
          color: Color(0xfff6f6f6),
        ),
        child: Center(child: Text('10 mm')),
      );
    }),
  );
}
/*
Text(
"Description",
style: TextStyle(
color: Color(0xff2d2d2d),
fontSize: 20,
),
),*/
/*
Text(
"What are Easy Fan Volume Lashes? They allow you to create a\nperfect fan quickly and easily, even for new lash artists. Unique\nlash strips prevent the lashes from splitting at the base, allowing\nyou to create perfect 2D~10D fans.",
style: TextStyle(
color: Color(0xff6a6a6a),
fontSize: 12,
),
),*/
