import 'package:flutter/material.dart';
import 'package:the_lash_supply/modules/product_description/models/product_details_modal.dart';
Widget productImage(context,{required List<ProductDetails>? modal}){
  return SizedBox(
      width: double.infinity,
      height: 150,
      child: Image.network("http://3.114.92.202:4003/uploads/${modal?[0].filename}"),
  );
}
