import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:the_lash_supply/modules/product_description/models/product_details_modal.dart';
Widget imageWidget (context, {required List<ProductDetails>? modal}){
  return SizedBox(
    height: MediaQuery.of(context).size.height*0.27,
    width: MediaQuery.of(context).size.width,
   child: CarouselSlider(
     options: CarouselOptions(height: 400.0,autoPlay: true,reverse: true),
     items: [0,1,2].map((i) {
       return Builder(
         builder: (BuildContext context) {
           return Container(
               height: 180,
               width: double.infinity,
               margin: EdgeInsets.symmetric(horizontal: 5.0),
             child: Image.network(modal![i].filename!),
             /*child: Image.network("http://3.114.92.202:4003/uploads/${modal?[i].filename}"),*/
           );
         },
       );
     }).toList(),
   ),
  );
}