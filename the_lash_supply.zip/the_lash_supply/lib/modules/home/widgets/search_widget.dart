
import 'package:flutter/material.dart';

Widget searchWidget(context){
  return Padding(
    padding: const EdgeInsets.only(left: 8, right: 8, top: 12),
    child: Container(
      width: MediaQuery.of(context).size.width,
      height: 45,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color:Color(0xffececec), width: 1.50, ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children:[
            Container(
              width: 18,
              height: 18,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(Icons.search),
            ),
            SizedBox(width: 33),
            Text(
              "Search Products ",
              style: TextStyle(
                color: Color(0xff6f6f6f),
                fontSize: 18,
                fontFamily: "FiraSans",
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    ),
  );
}