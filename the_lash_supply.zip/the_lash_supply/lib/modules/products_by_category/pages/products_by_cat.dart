import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:the_lash_supply/details_widget.dart';
import 'package:the_lash_supply/modules/products_by_category/widget/product_widget.dart';

import '../../category/bloc/category_bloc/category_bloc.dart';
import '../../category/model/category_modal.dart';
import '../../favourite/widgets/favourite_widgets.dart';
import '../../widgets/custom_app_bar.dart';

class ProductsByCategory extends StatefulWidget {
  const ProductsByCategory({Key? key}) : super(key: key);

  @override
  State<ProductsByCategory> createState() => _ProductsByCategoryState();
}

class _ProductsByCategoryState extends State<ProductsByCategory> {
  final CategoryBloc categoryBloc = CategoryBloc();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Color(0xff272727),
        ),
        backgroundColor: Colors.white,
        centerTitle: false,
        title: appBar(context, 'Products'),
      ),
        body: BlocProvider<CategoryBloc>(
          create: (_) => categoryBloc..add(LoadCategoryEvent()),

          child: BlocListener<CategoryBloc, CategoryState>(
            listener: (context, state) {
              if(state is CategorySuccess){

              }
            },
            child: BlocBuilder<CategoryBloc,CategoryState>(
              builder: (BuildContext context, state){
                if(state is CategoryInitial){
                  return Center(child: CircularProgressIndicator());
                }
                if(state is CategorySuccess){
                  return categoryProduct(context, modal: state.modal);
                }
                return Container();
              },
            ),
          ),
        ),
        );
  }
}
Widget categoryProduct(context,{required List<CategoryModal>? modal}){
  return Column(
      children: [
      productsByCat(context,'View Details',modal: modal),
  ],
  );
}
