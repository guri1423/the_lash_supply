
import 'package:flutter/material.dart';

Widget profilePic(context){
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 30),
    child: Column(
      children: [
        CircleAvatar(
          radius: 60,
        backgroundImage: AssetImage('assets/images/profile.png')
        )
      ],
    ),
  );
}