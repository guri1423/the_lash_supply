import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AppFontsHeading {
  static FontWeight headingFontWeight = FontWeight.w700;
  static FontStyle headingStyle = FontStyle.normal;
  static double customFontSize = 30;
  static String customFontHeading = 'Arya';
  static String customFontText = 'FiraSans';


}