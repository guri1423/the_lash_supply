package com.example.the_lash_supply

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
