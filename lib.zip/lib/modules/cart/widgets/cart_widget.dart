

import 'package:flutter/material.dart';

Widget cartWidget (context){

  return SizedBox(
    height: MediaQuery.of(context).size.height*0.42,
    width: MediaQuery.of(context).size.width,
    child: ListView.builder(
      itemCount: 2,
      itemBuilder: (BuildContext context, int index){
        return Container(
          height: MediaQuery.of(context).size.height*0.20,
          width: MediaQuery.of(context).size.width,
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.asset('assets/images/Mask group.png'),
                  SizedBox(width: 30,),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Magic Lash",
                        style: TextStyle(
                          color: Color(0xff333232),
                          fontSize: 18,
                          fontFamily: "Arya",
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 25,),
                      Text(
                        "\$14.00",
                        style: TextStyle(
                          color: Color(0xff333232),
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 25,),
                      Container(
                        width: 120,
                        height: 28,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children:[
                            Container(
                              width: 34,
                              height: 28,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xffcacaca), width: 1, ),
                                color: Color(0xffeaeaea),
                              ),
                              child: Icon(Icons.remove),

                            ),

                            SizedBox(width: 10.50),
                            Text(
                              '1',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Color(0xff2d2d2d),
                                fontSize: 18,
                                fontFamily: "Roboto",
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(width: 10.50),
                            Container(
                              width: 34,
                              height: 28,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xffcacaca), width: 1, ),
                                color: Color(0xffeaeaea),
                              ),
                              child: Icon(Icons.add),


                            ),
                          ],
                        ),
                      ),

                    ],
                  ),
                  Spacer(),
                  Icon(Icons.close),
                ],
              ),
              Divider(
                thickness: 2,
              )

            ],
          ),
        );
      },

    ),
  );
}