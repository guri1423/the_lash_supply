import 'package:flutter/material.dart';
import 'package:the_lash_supply/core/utils/colors.dart';
import 'package:the_lash_supply/core/utils/fonts.dart';

Widget textWidget(context){
  return Row(
    mainAxisAlignment: MainAxisAlignment.start,
    children: [
     SizedBox(width: 132),
        Text(
          "Categories",
          style: TextStyle(
            color: AppColors.blackContainer,
            fontSize: AppFontsHeading.customFontSize,
            fontFamily: AppFontsHeading.customFontText,
            fontWeight: AppFontsHeading.headingFontWeight,
          ),
        ),
    ],
  );
}