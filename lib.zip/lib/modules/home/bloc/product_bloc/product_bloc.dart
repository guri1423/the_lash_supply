import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import 'package:the_lash_supply/modules/product_description/models/product_details_modal.dart';

import '../../../onboarding/repository/auth_repositry.dart';

part 'product_event.dart';
part 'product_state.dart';

class ProductBloc extends Bloc<ProductEvent, ProductState> {
   AuthRepository authRepository = AuthRepository();

  ProductBloc() : super(ProductInitial()) {

    on<LoadProductEvent>((event, emit) async {

     if (event is LoadProductEvent){
       emit(ProductLoading());

      try{
        List<ProductDetails>? modal = await authRepository.product();
        emit(ProductSuccess(modal!));
      }
      catch(e){

        debugPrint(e.toString());
        emit(ProductFail());
      }

     }


    }
    );
  }
}
