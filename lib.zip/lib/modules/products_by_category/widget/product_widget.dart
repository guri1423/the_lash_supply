import 'package:flutter/material.dart';
import 'package:the_lash_supply/modules/categories_description/pages/categories_page.dart';
import 'package:the_lash_supply/modules/category/model/category_modal.dart';
import 'package:the_lash_supply/modules/product_description/models/product_details_modal.dart';
import 'package:the_lash_supply/details_widget.dart';

Widget productsByCat(context, text, {required List<CategoryModal>? modal}) {
  return SizedBox(
    height: MediaQuery.of(context).size.height * 0.86,
    width: MediaQuery.of(context).size.width,
    child: ListView.separated(
      separatorBuilder: (BuildContext context, int index) {
        return const Divider();
      },
      itemCount: 6,
      itemBuilder: (BuildContext context, int index) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
          child: Container(
            height: MediaQuery.of(context).size.height * 0.20,
            width: MediaQuery.of(context).size.width,
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    /*  Image.asset('assets/images/Mask group.png'),*/
                    Image.network(modal![index].filename!,height: 135,),
                    SizedBox(
                /*      height: MediaQuery.of(context).size.height * 0.15,*/
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            modal![index].cateName!,
                            style: const TextStyle(
                              color: Color(0xff333232),
                              fontSize: 18,
                              fontFamily: "Arya",
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const Text(
                            "\$14.00",
                            style: TextStyle(
                              color: Color(0xff333232),
                              fontSize: 16,
                            ),
                          ),
                         /* Container(
                            width: 100,
                            height: 40,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(2),
                              color: Colors.red,
                            ),
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const CategoriesPage()));
                              },
                              child: Center(
                                child: Text(
                                  text,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontFamily: "Roboto",
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ),
                          ),*/
                          ElevatedButton(
                            child: Text(text),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red,
                            ),
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context)=>CategoriesPage()));
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}
/*MaterialButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            CategoriesPage()));
                              },*/
