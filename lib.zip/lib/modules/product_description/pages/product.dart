import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:the_lash_supply/modules/product_description/widgets/product_image_widget.dart';
import 'package:the_lash_supply/modules/product_description/widgets/product_text_widget.dart';
import '../../../core/utils/colors.dart';
import '../../../home1.dart';
import '../../home/bloc/product_bloc/product_bloc.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_app_button.dart';
import '../models/product_details_modal.dart';

class ProductDescription extends StatefulWidget {
  ProductDescription({Key? key}) : super(key: key);

  @override
  State<ProductDescription> createState() => _ProductDescriptionState();
}

class _ProductDescriptionState extends State<ProductDescription> {
  final ProductBloc productBloc = ProductBloc();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          iconTheme: IconThemeData(
            color: Color(0xff272727),
          ),
          backgroundColor: Colors.white,
          centerTitle: false,
          title: Row(
            children: [
              appBar(context, 'Magic Lashes'),
              Spacer(),
              SizedBox(
                width: 10,
              ),
              Icon(
                Icons.favorite_border,
                color: AppColors.primaryColor,
              ),
              SizedBox(
                width: 10,
              ),
              Icon(
                Icons.text_snippet_outlined,
                color: AppColors.primaryColor,
              )
            ],
          ),
        ),
        body: BlocProvider<ProductBloc>(
            create: (_) => productBloc..add(LoadProductEvent()),
            child: BlocListener<ProductBloc, ProductState>(
                listener: (context, state) {
              if (state is ProductSuccess) {}
            }, child: BlocBuilder<ProductBloc, ProductState>(
                    builder: (BuildContext context, state) {
              if (state is ProductSuccess) {
                return homeInitial(context, modal: state.modal);
              }
              return Container();
            }))));
  }
}
Widget homeInitial(context, {required List<ProductDetails>? modal}) {
  return Column(
      children: [
        productImage(context, modal: modal),
        SizedBox(height: 5),
        productText(context, modal: modal),
        SizedBox(height: 5),
        ElevatedButton(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
            child: Text(
              'Add to Cart',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontStyle: FontStyle.normal),
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
          ),
          onPressed: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => Home1()));
          },
        ),
      ],
    );
}
/*
Padding(padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 16),
child: Column(
children: [
productImage(context),
SizedBox(height: 5,),
productText(context),
SizedBox(height: 15,),
appButton(context, AppColors.primaryColor, 'Add to Cart', AppColors.textColor, action: (){
setState((){
Navigator.pushReplacement(context,MaterialPageRoute(builder: (context) => Home1()));
});
}),
],
),
),*/
