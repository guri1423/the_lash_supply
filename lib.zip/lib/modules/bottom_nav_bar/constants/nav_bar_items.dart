

enum NavbarItem {Home, Category, Cart, MyOrder, MyAccount }